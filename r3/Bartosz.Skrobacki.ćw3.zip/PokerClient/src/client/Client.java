/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 *
 * @author Bartosz
 */
public class Client implements Closeable {
    
    private int port;
    
    private String address;
    
    private Socket socket;
    
    private BufferedReader input;
    
    private PrintWriter output;
    
    
    public Client(String propertiesFileName) {
        try{
            Properties properties = new Properties();
            FileInputStream in = new FileInputStream(propertiesFileName);
            properties.load(in);
            port = Integer.parseInt(properties.getProperty("port"));
            address = properties.getProperty("server_address");
            socket = new Socket(address,port);
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            output = new PrintWriter(socket.getOutputStream(), true);

        } catch(IOException e){
            System.err.println("Connection does not work");
           
        }
    }
    
    public String CheckPokerHand()
    {
        try{
            output.println("CheckPokerHand");
            String controlMessage=input.readLine();
        

            if(controlMessage.contains("100"))
            return input.readLine();
            
            if(controlMessage.contains("200")){
                return "Connection between client and server wasn't executed properly";
            } else{
                return controlMessage;
            }
        }
        
        catch(IOException e){
            return e.getMessage();
        }
    }
    
    public int CardsToDisplay(int i){
        try{
            output.println("CardtoDisplay");
            String controlMessage=input.readLine();
            if(controlMessage.contains("100"))
                output.println(i);
            controlMessage=input.readLine();
            if(controlMessage.contains("101"))
               return Integer.parseInt(input.readLine());
            
        } catch(IOException e){
           System.err.println("IOException in CardsToDisplay");
        }
        return 0;
    }
    
    
           
      public List<String> getAvailableCommands() throws IOException{
        output.println("HELP");
        String controlMessage=input.readLine();
        if(controlMessage.contains("150")){
            controlMessage = input.readLine();
            return Arrays.asList(controlMessage.split("|"));
        }else{
            throw new IOException("Unexpected response from server");
        }
    }
    
   @Override
    public void close() throws IOException {
        if(socket!=null){
            socket.close();
        }
    } 
    
}
