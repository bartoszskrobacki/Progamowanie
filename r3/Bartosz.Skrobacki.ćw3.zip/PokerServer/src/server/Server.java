/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Properties;

/**
 *
 * @author Bartosz
 */
public class Server implements Closeable {
    
    private int PORT;
    
    private ServerSocket serverSocket;
    
    public Server() throws IOException{
        serverSocket = new ServerSocket(PORT);
    }
    
    public Server(String propertiesFileName) throws IOException{
        Properties properties = new Properties();
        FileInputStream in = new FileInputStream(propertiesFileName);
        properties.load(in);
        PORT=Integer.parseInt(properties.getProperty("port"));
        serverSocket = new ServerSocket(PORT);
        while(true)
        new SingleConnection(serverSocket.accept()).start();
    }
    
    public void close() throws IOException{
        if(serverSocket != null){
            serverSocket.close();
        }
    }
}
