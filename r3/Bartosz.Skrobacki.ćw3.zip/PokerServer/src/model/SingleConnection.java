/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import server.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import model.Game;

/**
 *
 * @author Bartosz
 */
public class SingleConnection extends Thread implements Closeable {
    
    private Socket socket;
    
    private BufferedReader input;
    
    private PrintWriter output;
    
    public SingleConnection(Socket socket) throws IOException{
        this.socket = socket;
        output = new PrintWriter(
            new BufferedWriter(
                new OutputStreamWriter(
                    socket.getOutputStream())),true);
        input = new BufferedReader(
                new InputStreamReader(
                    socket.getInputStream()));
    }
    
    @Override
    public final void run() {
        try{
            while(true) {
                String message =  input.readLine();
                if("Turnon".equals(message)){
                    //TO DO
                }
                else
                {
                    output.print("nunu");
                }
            }
            
        } catch(IOException e){
            System.err.println("Single Server Connection exception: " + e.getMessage());
        }
    }
    
    private final void checkPokerHand(){
        
        Game game = new Game();
        output.println(game.getResult());
        
        output.println(game.cardsToDisplay(1));
        output.println(game.cardsToDisplay(2));
        output.println(game.cardsToDisplay(3));
        output.println(game.cardsToDisplay(4));
        output.println(game.cardsToDisplay(5));
        
    }
    
    
    @Override
    public void close() throws IOException{
        if(socket != null){
            socket.close();
        }
    }
    
}
